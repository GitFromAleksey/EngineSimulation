#include "stdafx.h"
#include "EngineBase.h"


EngineBase::EngineBase(void)
{
}


EngineBase::~EngineBase(void)
{
}
