#pragma once


class EngineBase
{
public:
	EngineBase(void);
	~EngineBase(void);

	virtual float getWorkTime()const = 0;
	virtual float getTengine()const = 0;
	virtual float getToverheat()const = 0;

	virtual void setTenv(float &Tenv) = 0;
	virtual void Init() = 0;
	virtual void run() = 0;
};

