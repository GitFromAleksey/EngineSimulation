#include "stdafx.h"
#include "Stend.h"


Stend::Stend()
{
	this->pEngine = nullptr;
	workTime = 0;
	timeOut = 0;
}

bool Stend::TestEngine()
{
	if(pEngine == nullptr) return false;

	pEngine->Init();

	while(pEngine->getTengine() < pEngine->getToverheat())
	{
		pEngine->run();

		workTime = pEngine->getWorkTime();

		if(workTime > timeOut)
		{
			return false;
		}
	}

	return true;
}
